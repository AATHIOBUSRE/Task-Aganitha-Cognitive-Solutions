# Get Papers List

Fetch PubMed research papers with pharmaceutical or biotech company affiliations.

## 🔧 Installation

```bash
poetry install

To run the command
example command : poetry run get-papers-list "cancer vaccine" -f results.csv
